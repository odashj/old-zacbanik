Directory to place additional CKEditor plugins in. You can then activate them
from your CKEditor field settings. Place each plugin in its own directory 
having the same name as the plugin. 
