<?php if(!defined("PROCESSWIRE_INSTALL")) die();
$info = array(
	'title' => "Zac's Portfolio Profile", 
	'summary' => "This is a profile for Zac's portfolio website.", 
	'screenshot' => "screen_shot_2018-04-22_at_7_24_32_pm.png"
	);
